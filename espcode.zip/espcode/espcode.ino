#include <Arduino.h>
#include <WiFi.h>
#include <esp_camera.h>
#include <esp_http_server.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

namespace Pins {
constexpr int alcoholAnalog = 3;
constexpr int camSiod = 4;
constexpr int camSioc = 5;
constexpr int camVsync = 6;
constexpr int camHref = 7;
constexpr int camY4 = 8;
constexpr int camY3 = 9;
constexpr int camY5 = 10;
constexpr int camY2 = 11;
constexpr int camY6 = 12;
constexpr int camPclk = 13;
constexpr int camXclk = 15;
constexpr int camY9 = 16;
constexpr int camY8 = 17;
constexpr int camY7 = 18;

constexpr int buzzer = 2;
constexpr int relay = 45;
constexpr int rampRpwm = 39;
constexpr int rampLpwm = 40;
constexpr int driversEnable = 47;
constexpr int wheelchairRpwm = 48;
constexpr int wheelchairLpwm = 1;
}  // namespace Pins

namespace BleUuids {
static BLEUUID service("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
static BLEUUID notify("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
static BLEUUID write("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
}  // namespace BleUuids

constexpr char kBleDeviceName[] = "ESP32_DRIVE";
constexpr char kCameraApSsid[] = "AutoNexus-X-CAM";
constexpr char kCameraApPassword[] = "autonexus123";
constexpr uint32_t kPulseMs = 650;
constexpr uint32_t kBuzzerAutoStopMs = 5000;
constexpr bool kDriverEnableActiveHigh = true;
constexpr int kAlcoholThreshold = 1800;
constexpr uint32_t kAlcoholSampleIntervalMs = 1000;

BLECharacteristic* gNotifyCharacteristic = nullptr;
httpd_handle_t gCameraHttpd = nullptr;
httpd_handle_t gStreamHttpd = nullptr;
bool gClientConnected = false;
bool gBuzzerActive = false;
bool gSleepRelayRequested = false;
bool gAlcoholRelayRequested = false;
unsigned long gBuzzerStartMs = 0;
unsigned long gLastAlcoholSampleMs = 0;

enum class RampDirection {
  none,
  inwards,
  outwards,
};

RampDirection gRampDirection = RampDirection::none;

void sendStatus(const String& message) {
  Serial.println(message);
  if (!gClientConnected || gNotifyCharacteristic == nullptr) {
    return;
  }

  gNotifyCharacteristic->setValue(message.c_str());
  gNotifyCharacteristic->notify();
}

void setDriverEnabled(bool enabled) {
  const bool outputHigh = enabled == kDriverEnableActiveHigh;
  digitalWrite(Pins::driversEnable, outputHigh ? HIGH : LOW);
}

void stopDriverPair(int rpwmPin, int lpwmPin) {
  digitalWrite(rpwmPin, LOW);
  digitalWrite(lpwmPin, LOW);
}

void setDriverPair(int rpwmPin, int lpwmPin, bool forward) {
  digitalWrite(rpwmPin, forward ? HIGH : LOW);
  digitalWrite(lpwmPin, forward ? LOW : HIGH);
}

void stopAllMotion() {
  stopDriverPair(Pins::rampRpwm, Pins::rampLpwm);
  stopDriverPair(Pins::wheelchairRpwm, Pins::wheelchairLpwm);
  setDriverEnabled(false);
  gRampDirection = RampDirection::none;
}

void pulseDriver(int rpwmPin, int lpwmPin, bool forward, const String& status) {
  stopDriverPair(rpwmPin, lpwmPin);
  setDriverEnabled(true);
  delay(30);
  setDriverPair(rpwmPin, lpwmPin, forward);
  delay(kPulseMs);
  stopDriverPair(rpwmPin, lpwmPin);
  setDriverEnabled(false);
  sendStatus(status);
}

void setBuzzer(bool enabled) {
  gBuzzerActive = enabled;
  digitalWrite(Pins::buzzer, enabled ? HIGH : LOW);
  gBuzzerStartMs = enabled ? millis() : 0;
}

void setRelay(bool enabled) {
  digitalWrite(Pins::relay, enabled ? HIGH : LOW);
}

void updateRelayOutput() {
  setRelay(gSleepRelayRequested || gAlcoholRelayRequested);
}

void clearAlertOutputs() {
  setBuzzer(false);
  gSleepRelayRequested = false;
  updateRelayOutput();
}

void handleDoorLock() {
  sendStatus("Door lock UI only on ESP32-S3 single-board profile");
}

void handleDoorUnlock() {
  sendStatus("Door unlock UI only on ESP32-S3 single-board profile");
}

void handleRampInStart() {
  if (gRampDirection != RampDirection::none) {
    sendStatus("Ramp already active");
    return;
  }

  stopDriverPair(Pins::rampRpwm, Pins::rampLpwm);
  setDriverEnabled(true);
  delay(30);
  setDriverPair(Pins::rampRpwm, Pins::rampLpwm, true);
  gRampDirection = RampDirection::inwards;
  sendStatus("Ramp moving inward");
}

void handleRampOutStart() {
  if (gRampDirection != RampDirection::none) {
    sendStatus("Ramp already active");
    return;
  }

  stopDriverPair(Pins::rampRpwm, Pins::rampLpwm);
  setDriverEnabled(true);
  delay(30);
  setDriverPair(Pins::rampRpwm, Pins::rampLpwm, false);
  gRampDirection = RampDirection::outwards;
  sendStatus("Ramp moving outward");
}

void handleRampStop() {
  stopDriverPair(Pins::rampRpwm, Pins::rampLpwm);
  setDriverEnabled(false);
  gRampDirection = RampDirection::none;
  sendStatus("Ramp stopped");
}

void handleWheelchairLock() {
  pulseDriver(
      Pins::wheelchairRpwm,
      Pins::wheelchairLpwm,
      true,
      "Wheelchair lock pulse");
}

void handleWheelchairUnlock() {
  pulseDriver(
      Pins::wheelchairRpwm,
      Pins::wheelchairLpwm,
      false,
      "Wheelchair unlock pulse");
}

void handleAlertSleepStart() {
  gSleepRelayRequested = false;
  updateRelayOutput();
  setBuzzer(true);
  sendStatus("Buzzer alert active");
}

void handleAlertRelayOn() {
  setBuzzer(false);
  gSleepRelayRequested = true;
  updateRelayOutput();
  sendStatus("Relay output active");
}

void handleAlertClear() {
  clearAlertOutputs();
  sendStatus("Alert outputs cleared");
}

void sampleAlcoholSensor() {
  const unsigned long now = millis();
  if (now - gLastAlcoholSampleMs < kAlcoholSampleIntervalMs) {
    return;
  }

  gLastAlcoholSampleMs = now;
  const int alcoholValue = analogRead(Pins::alcoholAnalog);
  Serial.printf("Alcohol raw: %d\n", alcoholValue);

  const bool overThreshold = alcoholValue >= kAlcoholThreshold;
  if (overThreshold != gAlcoholRelayRequested) {
    gAlcoholRelayRequested = overThreshold;
    updateRelayOutput();

    if (overThreshold) {
      sendStatus("Alcohol high: ignition kill active");
    } else {
      sendStatus("Alcohol normal: ignition relay released");
    }
  }
}

String normalizeCommand(String command) {
  command.trim();
  command.replace("\r", "");
  command.replace("\n", "");
  command.toUpperCase();
  return command;
}

void dispatchCommand(String rawCommand) {
  const String command = normalizeCommand(rawCommand);
  if (command.length() == 0) {
    return;
  }

  if (command == "LOCK") {
    handleDoorLock();
  } else if (command == "UNLOCK") {
    handleDoorUnlock();
  } else if (command == "RAMP_IN_START" || command == "RAMP_IN") {
    handleRampInStart();
  } else if (command == "RAMP_OUT_START" || command == "RAMP_OUT") {
    handleRampOutStart();
  } else if (command == "RAMP_STOP" || command == "STOP") {
    handleRampStop();
  } else if (command == "RAMP_LOCK" || command == "WHEELCHAIR_LOCK" ||
             command == "CHAIR_LOCK") {
    handleWheelchairLock();
  } else if (command == "RAMP_UNLOCK" || command == "WHEELCHAIR_UNLOCK" ||
             command == "CHAIR_UNLOCK") {
    handleWheelchairUnlock();
  } else if (command == "ALERT_SLEEP_START" || command == "ALERT_SLEEP") {
    handleAlertSleepStart();
  } else if (command == "ALERT_RELAY_ON") {
    handleAlertRelayOn();
  } else if (command == "ALERT_CLEAR") {
    handleAlertClear();
  } else {
    sendStatus("Unknown command: " + command);
  }
}

static esp_err_t captureHandler(httpd_req_t* req) {
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) {
    httpd_resp_send_500(req);
    return ESP_FAIL;
  }

  httpd_resp_set_type(req, "image/jpeg");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  const esp_err_t result = httpd_resp_send(
      req,
      reinterpret_cast<const char*>(fb->buf),
      fb->len);
  esp_camera_fb_return(fb);
  return result;
}

static esp_err_t streamHandler(httpd_req_t* req) {
  camera_fb_t* fb = nullptr;
  esp_err_t result =
      httpd_resp_set_type(req, "multipart/x-mixed-replace;boundary=frame");
  if (result != ESP_OK) {
    return result;
  }

  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

  while (true) {
    fb = esp_camera_fb_get();
    if (!fb) {
      return ESP_FAIL;
    }

    result = httpd_resp_send_chunk(req, "--frame\r\n", strlen("--frame\r\n"));
    if (result == ESP_OK) {
      result = httpd_resp_send_chunk(
          req,
          "Content-Type: image/jpeg\r\n\r\n",
          strlen("Content-Type: image/jpeg\r\n\r\n"));
    }
    if (result == ESP_OK) {
      result = httpd_resp_send_chunk(
          req,
          reinterpret_cast<const char*>(fb->buf),
          fb->len);
    }
    if (result == ESP_OK) {
      result = httpd_resp_send_chunk(req, "\r\n", 2);
    }

    esp_camera_fb_return(fb);
    if (result != ESP_OK) {
      return result;
    }
  }
}

void setupCamera() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Pins::camY2;
  config.pin_d1 = Pins::camY3;
  config.pin_d2 = Pins::camY4;
  config.pin_d3 = Pins::camY5;
  config.pin_d4 = Pins::camY6;
  config.pin_d5 = Pins::camY7;
  config.pin_d6 = Pins::camY8;
  config.pin_d7 = Pins::camY9;
  config.pin_xclk = Pins::camXclk;
  config.pin_pclk = Pins::camPclk;
  config.pin_vsync = Pins::camVsync;
  config.pin_href = Pins::camHref;
  config.pin_sccb_sda = Pins::camSiod;
  config.pin_sccb_scl = Pins::camSioc;
  config.pin_pwdn = -1;
  config.pin_reset = -1;
  config.xclk_freq_hz = 15000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size = FRAMESIZE_QQVGA;
  config.jpeg_quality = 15;
  config.fb_count = 1;
  config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
  config.fb_location = CAMERA_FB_IN_DRAM;

  if (esp_camera_init(&config) != ESP_OK) {
    Serial.println("ESP32-S3 camera init failed");
    while (true) {
      delay(1000);
    }
  }
}

void startCameraServer() {
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.server_port = 80;

  httpd_uri_t captureUri = {
      .uri = "/capture",
      .method = HTTP_GET,
      .handler = captureHandler,
      .user_ctx = nullptr};

  if (httpd_start(&gCameraHttpd, &config) == ESP_OK) {
    httpd_register_uri_handler(gCameraHttpd, &captureUri);
  }

  httpd_config_t streamConfig = HTTPD_DEFAULT_CONFIG();
  streamConfig.server_port = 81;

  httpd_uri_t streamUri = {
      .uri = "/stream",
      .method = HTTP_GET,
      .handler = streamHandler,
      .user_ctx = nullptr};

  if (httpd_start(&gStreamHttpd, &streamConfig) == ESP_OK) {
    httpd_register_uri_handler(gStreamHttpd, &streamUri);
  }
}

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* server) override {
    gClientConnected = true;
    sendStatus("BLE client connected");
    server->getAdvertising()->start();
  }

  void onDisconnect(BLEServer* server) override {
    gClientConnected = false;
    stopAllMotion();
    clearAlertOutputs();
    sendStatus("BLE client disconnected");
    server->getAdvertising()->start();
  }
};

class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* characteristic) override {
    String command = characteristic->getValue();
    if (command.length() == 0) {
      return;
    }

    Serial.print("BLE RX: ");
    Serial.println(command);
    dispatchCommand(command);
  }
};

void setupBle() {
  BLEDevice::init(kBleDeviceName);
  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());

  BLEService* service = server->createService(BleUuids::service);

  gNotifyCharacteristic = service->createCharacteristic(
      BleUuids::notify,
      BLECharacteristic::PROPERTY_NOTIFY | BLECharacteristic::PROPERTY_READ);
  gNotifyCharacteristic->addDescriptor(new BLE2902());
  gNotifyCharacteristic->setValue("AutoNexus-X ready");

  BLECharacteristic* writeCharacteristic = service->createCharacteristic(
      BleUuids::write,
      BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  writeCharacteristic->setCallbacks(new RxCallbacks());

  service->start();

  BLEAdvertising* advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(BleUuids::service);
  advertising->setScanResponse(true);
  advertising->setMinPreferred(0x06);
  advertising->setMinPreferred(0x12);
  advertising->start();

  Serial.println("BLE advertising started");
}

void setupPins() {
  pinMode(Pins::alcoholAnalog, INPUT);
  pinMode(Pins::driversEnable, OUTPUT);
  pinMode(Pins::rampRpwm, OUTPUT);
  pinMode(Pins::rampLpwm, OUTPUT);
  pinMode(Pins::wheelchairRpwm, OUTPUT);
  pinMode(Pins::wheelchairLpwm, OUTPUT);
  pinMode(Pins::buzzer, OUTPUT);
  pinMode(Pins::relay, OUTPUT);

  digitalWrite(Pins::rampRpwm, LOW);
  digitalWrite(Pins::rampLpwm, LOW);
  digitalWrite(Pins::wheelchairRpwm, LOW);
  digitalWrite(Pins::wheelchairLpwm, LOW);
  setRelay(false);
  clearAlertOutputs();
  setDriverEnabled(false);
}

void setupWifiAp() {
  WiFi.mode(WIFI_AP);
  WiFi.softAP(kCameraApSsid, kCameraApPassword);
  Serial.print("Camera AP SSID: ");
  Serial.println(kCameraApSsid);
  Serial.print("Camera AP Password: ");
  Serial.println(kCameraApPassword);
  Serial.print("Capture URL: http://");
  Serial.print(WiFi.softAPIP());
  Serial.println("/capture");
  Serial.print("Stream URL: http://");
  Serial.print(WiFi.softAPIP());
  Serial.println(":81/stream");
}

void setup() {
  Serial.begin(115200);
  delay(500);
  analogReadResolution(12);

  setupPins();
  setupCamera();
  setupWifiAp();
  startCameraServer();
  setupBle();

  Serial.println("AutoNexus-X single-board ESP32-S3 controller booted");
  Serial.printf(
      "Ramp motor: GPIO %d / GPIO %d\n",
      Pins::rampRpwm,
      Pins::rampLpwm);
  Serial.printf(
      "Wheelchair lock: GPIO %d / GPIO %d\n",
      Pins::wheelchairRpwm,
      Pins::wheelchairLpwm);
  Serial.printf(
      "Buzzer: GPIO %d  Relay: GPIO %d  Enable: GPIO %d\n",
      Pins::buzzer,
      Pins::relay,
      Pins::driversEnable);
  Serial.printf(
      "Alcohol sensor AO: GPIO %d  Threshold: %d\n",
      Pins::alcoholAnalog,
      kAlcoholThreshold);
}

void loop() {
  sampleAlcoholSensor();
  if (gBuzzerActive && gBuzzerStartMs != 0 &&
      millis() - gBuzzerStartMs >= kBuzzerAutoStopMs) {
    setBuzzer(false);
    sendStatus("Buzzer timed out after 5 seconds");
  }
}
