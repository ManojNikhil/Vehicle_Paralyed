#include <Arduino.h>

// Normal ESP32 sensor monitor for:
// - 14x SR04M-2 ultrasonic sensors
// - 1x TF-Luna LiDAR
//
// Note:
// Your message says 13 ultrasonic sensors, but the placement you gave
// adds up to 14 total:
// - 4 front
// - 3 left
// - 3 right
// - 4 rear
//
// This sketch is written for 14 ultrasonic sensors.
//
// IMPORTANT:
// If your SR04M-2 echo output is 5V, use a level shifter or divider
// before feeding the ESP32 echo pins.

namespace Pins {
constexpr int tfLunaRx = 16;
constexpr int tfLunaTx = 17;

constexpr int frontTrigger = 4;
constexpr int leftTrigger = 5;
constexpr int rightTrigger = 18;
constexpr int rearTrigger = 19;

constexpr int frontEcho1 = 21;
constexpr int frontEcho2 = 22;
constexpr int frontEcho3 = 23;
constexpr int frontEcho4 = 25;

constexpr int leftEcho1 = 26;
constexpr int leftEcho2 = 27;
constexpr int leftEcho3 = 32;

constexpr int rightEcho1 = 33;
constexpr int rightEcho2 = 34;
constexpr int rightEcho3 = 35;

constexpr int rearEcho1 = 36;
constexpr int rearEcho2 = 39;
constexpr int rearEcho3 = 13;
constexpr int rearEcho4 = 14;
}  // namespace Pins

constexpr unsigned long kEchoTimeoutUs = 30000;
constexpr unsigned long kUltrasonicPollMs = 200;
constexpr unsigned long kPrintIntervalMs = 300;
constexpr float kSoundSpeedCmPerUs = 0.0343f;

struct UltrasonicSensor {
  const char* name;
  int triggerPin;
  int echoPin;
  float lastDistanceCm;
  bool inRange;
};

UltrasonicSensor gSensors[] = {
    {"front_1", Pins::frontTrigger, Pins::frontEcho1, 0.0f, false},
    {"front_2", Pins::frontTrigger, Pins::frontEcho2, 0.0f, false},
    {"front_3", Pins::frontTrigger, Pins::frontEcho3, 0.0f, false},
    {"front_4", Pins::frontTrigger, Pins::frontEcho4, 0.0f, false},
    {"left_1", Pins::leftTrigger, Pins::leftEcho1, 0.0f, false},
    {"left_2", Pins::leftTrigger, Pins::leftEcho2, 0.0f, false},
    {"left_3", Pins::leftTrigger, Pins::leftEcho3, 0.0f, false},
    {"right_1", Pins::rightTrigger, Pins::rightEcho1, 0.0f, false},
    {"right_2", Pins::rightTrigger, Pins::rightEcho2, 0.0f, false},
    {"right_3", Pins::rightTrigger, Pins::rightEcho3, 0.0f, false},
    {"rear_1", Pins::rearTrigger, Pins::rearEcho1, 0.0f, false},
    {"rear_2", Pins::rearTrigger, Pins::rearEcho2, 0.0f, false},
    {"rear_3", Pins::rearTrigger, Pins::rearEcho3, 0.0f, false},
    {"rear_4", Pins::rearTrigger, Pins::rearEcho4, 0.0f, false},
};

struct TfLunaReading {
  int distanceCm;
  int strength;
  int temperatureC;
  bool valid;
};

TfLunaReading gLidar = {0, 0, 0, false};
unsigned long gLastUltrasonicPollMs = 0;
unsigned long gLastPrintMs = 0;

float measureDistanceCm(int triggerPin, int echoPin) {
  digitalWrite(triggerPin, LOW);
  delayMicroseconds(4);
  digitalWrite(triggerPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(triggerPin, LOW);

  const unsigned long duration =
      pulseIn(echoPin, HIGH, kEchoTimeoutUs);
  if (duration == 0) {
    return -1.0f;
  }

  return (duration * kSoundSpeedCmPerUs) * 0.5f;
}

void updateUltrasonicSensors() {
  for (auto& sensor : gSensors) {
    const float distance = measureDistanceCm(sensor.triggerPin, sensor.echoPin);
    sensor.inRange = distance >= 0.0f;
    sensor.lastDistanceCm = distance;
    delay(15);
  }
}

void updateTfLuna() {
  static uint8_t frame[9];
  static uint8_t index = 0;

  while (Serial2.available() > 0) {
    const uint8_t byteRead = static_cast<uint8_t>(Serial2.read());

    if (index == 0 && byteRead != 0x59) {
      continue;
    }
    if (index == 1 && byteRead != 0x59) {
      index = 0;
      continue;
    }

    frame[index++] = byteRead;
    if (index < sizeof(frame)) {
      continue;
    }

    index = 0;

    uint16_t checksum = 0;
    for (int i = 0; i < 8; i++) {
      checksum += frame[i];
    }

    if ((checksum & 0xFF) != frame[8]) {
      continue;
    }

    gLidar.distanceCm = frame[2] | (frame[3] << 8);
    gLidar.strength = frame[4] | (frame[5] << 8);
    gLidar.temperatureC = ((frame[6] | (frame[7] << 8)) / 8) - 256;
    gLidar.valid = true;
  }
}

void printUltrasonicGroup(const char* groupName, int startIndex, int count) {
  Serial.print(groupName);
  Serial.print(": ");

  for (int i = 0; i < count; i++) {
    const auto& sensor = gSensors[startIndex + i];
    Serial.print(sensor.name);
    Serial.print("=");
    if (sensor.inRange) {
      Serial.print(sensor.lastDistanceCm, 1);
      Serial.print("cm");
    } else {
      Serial.print("out");
    }

    if (i < count - 1) {
      Serial.print("  ");
    }
  }

  Serial.println();
}

void printSensorReadings() {
  Serial.println("----- sensor snapshot -----");
  printUltrasonicGroup("front", 0, 4);
  printUltrasonicGroup("left ", 4, 3);
  printUltrasonicGroup("right", 7, 3);
  printUltrasonicGroup("rear ", 10, 4);

  Serial.print("lidar: ");
  if (gLidar.valid) {
    Serial.print(gLidar.distanceCm);
    Serial.print("cm  strength=");
    Serial.print(gLidar.strength);
    Serial.print("  temp=");
    Serial.print(gLidar.temperatureC);
    Serial.println("C");
  } else {
    Serial.println("waiting for valid frame");
  }
}

void setupTriggerPins() {
  const int triggerPins[] = {
      Pins::frontTrigger,
      Pins::leftTrigger,
      Pins::rightTrigger,
      Pins::rearTrigger,
  };

  for (const int pin : triggerPins) {
    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
  }
}

void setupEchoPins() {
  const int echoPins[] = {
      Pins::frontEcho1, Pins::frontEcho2, Pins::frontEcho3, Pins::frontEcho4,
      Pins::leftEcho1,  Pins::leftEcho2,  Pins::leftEcho3,
      Pins::rightEcho1, Pins::rightEcho2, Pins::rightEcho3,
      Pins::rearEcho1,  Pins::rearEcho2,  Pins::rearEcho3,  Pins::rearEcho4,
  };

  for (const int pin : echoPins) {
    pinMode(pin, INPUT);
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);

  setupTriggerPins();
  setupEchoPins();

  Serial2.begin(115200, SERIAL_8N1, Pins::tfLunaRx, Pins::tfLunaTx);

  Serial.println("ESP32 sensor monitor started");
  Serial.println("Ultrasonic sensors: 14");
  Serial.println("TF-Luna LiDAR: enabled on UART2");
  Serial.println("Reading distances...");
}

void loop() {
  updateTfLuna();

  const unsigned long now = millis();
  if (now - gLastUltrasonicPollMs >= kUltrasonicPollMs) {
    gLastUltrasonicPollMs = now;
    updateUltrasonicSensors();
  }

  if (now - gLastPrintMs >= kPrintIntervalMs) {
    gLastPrintMs = now;
    printSensorReadings();
  }
}
