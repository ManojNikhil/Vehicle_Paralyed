import 'dart:async';

import 'package:flutter/foundation.dart';

import '../services/bluetooth_service.dart';

enum LockState { unknown, locked, unlocked }

enum RampDirection { none, in_, out_ }

enum RampLockState { unknown, locked, unlocked }

class ControlProvider extends ChangeNotifier {
  static const Duration _cooldownDuration = Duration(seconds: 2);
  static const String _rampInCommand = 'RAMP_IN_START';
  static const String _rampOutCommand = 'RAMP_OUT_START';
  static const String _rampStopCommand = 'RAMP_STOP';
  static const String _rampLockCommand = 'RAMP_LOCK';
  static const String _rampUnlockCommand = 'RAMP_UNLOCK';

  final BluetoothService _ble;

  ControlProvider(this._ble);

  LockState _lockState = LockState.unknown;
  bool _lockCooldown = false;
  bool _lockLoading = false;
  Timer? _lockCooldownTimer;

  RampDirection _activeRamp = RampDirection.none;
  RampLockState _rampLockState = RampLockState.unknown;
  bool _rampLockCooldown = false;
  bool _rampLockLoading = false;
  Timer? _rampLockCooldownTimer;

  LockState get lockState => _lockState;
  bool get lockCooldown => _lockCooldown;
  bool get lockLoading => _lockLoading;

  RampDirection get activeRamp => _activeRamp;
  bool get rampInActive => _activeRamp == RampDirection.in_;
  bool get rampOutActive => _activeRamp == RampDirection.out_;

  RampLockState get rampLockState => _rampLockState;
  bool get rampLockCooldown => _rampLockCooldown;
  bool get rampLockLoading => _rampLockLoading;

  Future<void> lock() async {
    if (_lockCooldown || _lockLoading) return;
    _lockState = LockState.locked;
    _startDoorLockCooldown();
    notifyListeners();
  }

  Future<void> unlock() async {
    if (_lockCooldown || _lockLoading) return;
    _lockState = LockState.unlocked;
    _startDoorLockCooldown();
    notifyListeners();
  }

  Future<void> lockRamp() async {
    if (_rampLockCooldown ||
        _rampLockLoading ||
        _activeRamp != RampDirection.none ||
        !_ble.isConnected) {
      return;
    }

    _rampLockLoading = true;
    notifyListeners();

    final ok = await _ble.sendCommand(_rampLockCommand);
    if (ok) {
      _rampLockState = RampLockState.locked;
    }

    _rampLockLoading = false;
    _startRampLockCooldown();
    notifyListeners();
  }

  Future<void> unlockRamp() async {
    if (_rampLockCooldown ||
        _rampLockLoading ||
        _activeRamp != RampDirection.none ||
        !_ble.isConnected) {
      return;
    }

    _rampLockLoading = true;
    notifyListeners();

    final ok = await _ble.sendCommand(_rampUnlockCommand);
    if (ok) {
      _rampLockState = RampLockState.unlocked;
    }

    _rampLockLoading = false;
    _startRampLockCooldown();
    notifyListeners();
  }

  Future<void> rampInStart() async {
    if (_activeRamp != RampDirection.none ||
        _rampLockState == RampLockState.locked ||
        !_ble.isConnected) {
      return;
    }

    final ok = await _ble.sendCommand(_rampInCommand);
    if (ok) {
      _activeRamp = RampDirection.in_;
      notifyListeners();
    }
  }

  Future<void> rampOutStart() async {
    if (_activeRamp != RampDirection.none ||
        _rampLockState == RampLockState.locked ||
        !_ble.isConnected) {
      return;
    }

    final ok = await _ble.sendCommand(_rampOutCommand);
    if (ok) {
      _activeRamp = RampDirection.out_;
      notifyListeners();
    }
  }

  Future<void> rampStop() async {
    if (_activeRamp == RampDirection.none) return;

    await _ble.sendCommand(_rampStopCommand);
    _activeRamp = RampDirection.none;
    notifyListeners();
  }

  void resetOnDisconnect() {
    _lockCooldownTimer?.cancel();
    _rampLockCooldownTimer?.cancel();

    _activeRamp = RampDirection.none;
    _lockState = LockState.unknown;
    _rampLockState = RampLockState.unknown;
    _lockCooldown = false;
    _lockLoading = false;
    _rampLockCooldown = false;
    _rampLockLoading = false;
    notifyListeners();
  }

  void _startDoorLockCooldown() {
    _lockCooldown = true;
    _lockCooldownTimer?.cancel();
    _lockCooldownTimer = Timer(_cooldownDuration, () {
      _lockCooldown = false;
      notifyListeners();
    });
  }

  void _startRampLockCooldown() {
    _rampLockCooldown = true;
    _rampLockCooldownTimer?.cancel();
    _rampLockCooldownTimer = Timer(_cooldownDuration, () {
      _rampLockCooldown = false;
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _lockCooldownTimer?.cancel();
    _rampLockCooldownTimer?.cancel();
    super.dispose();
  }
}
