import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/control_provider.dart';
import '../services/bluetooth_service.dart';
import '../widgets/connection_status_bar.dart';
import '../widgets/hardware_profile_section.dart';
import '../widgets/lock_control_section.dart';
import '../widgets/ramp_control_section.dart';

class DriveControlScreen extends StatefulWidget {
  const DriveControlScreen({super.key});

  @override
  State<DriveControlScreen> createState() => _DriveControlScreenState();
}

class _DriveControlScreenState extends State<DriveControlScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<BluetoothService>().startScanAndConnect();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<BluetoothService>(
      builder: (context, ble, _) {
        if (!ble.isConnected) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              context.read<ControlProvider>().resetOnDisconnect();
            }
          });
        }

        return Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            foregroundColor: Colors.white,
            title: const Text('Drive Control'),
          ),
          backgroundColor: const Color(0xFF0D0D1F),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.only(bottom: 16),
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
                  child: Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color:
                              const Color(0xFF00D4FF).withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: const Color(
                              0xFF00D4FF,
                            ).withValues(alpha: 0.3),
                          ),
                        ),
                        child: const Icon(
                          Icons.directions_car_filled_rounded,
                          color: Color(0xFF00D4FF),
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'AutoNexus-X',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 18,
                              letterSpacing: 0.5,
                            ),
                          ),
                          Text(
                            'ESP32-S3 vehicle control profile',
                            style: TextStyle(
                              color: Color(0xFF666688),
                              fontSize: 11,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const ConnectionStatusBar(),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 4,
                  ),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Divider(color: Color(0xFF2A2A4A)),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Text(
                          ble.isConnected
                              ? 'CONTROLS ACTIVE'
                              : 'CONTROLS DISABLED',
                          style: TextStyle(
                            color: ble.isConnected
                                ? const Color(0xFF00FF88)
                                : const Color(0xFF444466),
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                      const Expanded(
                        child: Divider(color: Color(0xFF2A2A4A)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                const LockControlSection(),
                const SizedBox(height: 4),
                const RampControlSection(),
                const SizedBox(height: 4),
                const HardwareProfileSection(),
                const SizedBox(height: 12),
                const Center(
                  child: Text(
                    'ESP32 BLE  |  Drive Control  |  AutoNexus-X',
                    style: TextStyle(
                      color: Color(0xFF444466),
                      fontSize: 10,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
