import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/ai_monitor_service.dart';
import '../services/bluetooth_service.dart';

class DriverMonitorScreen extends StatefulWidget {
  const DriverMonitorScreen({super.key});

  @override
  State<DriverMonitorScreen> createState() => _DriverMonitorScreenState();
}

class _DriverMonitorScreenState extends State<DriverMonitorScreen> {
  late final TextEditingController _urlController;

  @override
  void initState() {
    super.initState();
    final monitor = context.read<AiMonitorService>();
    _urlController = TextEditingController(text: monitor.espCamBaseUrl);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AiMonitorService>().initializeMonitoring();
    });
  }

  @override
  void dispose() {
    _urlController.dispose();
    context.read<AiMonitorService>().stopMonitoring();
    super.dispose();
  }

  Future<void> _restartMonitor() async {
    final monitor = context.read<AiMonitorService>();
    monitor.updateEspCamBaseUrl(_urlController.text);
    await monitor.stopMonitoring();
    await monitor.initializeMonitoring();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<AiMonitorService, BluetoothService>(
      builder: (context, monitor, ble, _) {
        return Scaffold(
          backgroundColor: const Color(0xFF07111D),
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            foregroundColor: Colors.white,
            title: const Text('Driver Monitor'),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Center(
                  child: Text(
                    ble.isConnected ? 'ESP LINKED' : 'ESP OFFLINE',
                    style: TextStyle(
                      color: ble.isConnected
                          ? const Color(0xFF00FF88)
                          : const Color(0xFF8A92B2),
                      fontWeight: FontWeight.w700,
                      fontSize: 11,
                      letterSpacing: 1.4,
                    ),
                  ),
                ),
              ),
            ],
          ),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
              children: [
                _MonitorSourceCard(
                  controller: _urlController,
                  monitor: monitor,
                  onReconnect: _restartMonitor,
                ),
                const SizedBox(height: 16),
                _MonitorCameraCard(monitor: monitor),
                const SizedBox(height: 16),
                _MonitorStatusCard(monitor: monitor),
                const SizedBox(height: 16),
                _MonitorThresholdCard(monitor: monitor),
                const SizedBox(height: 16),
                _AlertRouteCard(
                  isEspConnected: ble.isConnected,
                  relayActive: monitor.relayActive,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _MonitorSourceCard extends StatelessWidget {
  const _MonitorSourceCard({
    required this.controller,
    required this.monitor,
    required this.onReconnect,
  });

  final TextEditingController controller;
  final AiMonitorService monitor;
  final Future<void> Function() onReconnect;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF101A2B),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFF24304D)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'ESP32-CAM source',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Use the ESP32-CAM capture endpoint. Example: http://192.168.4.1 or your camera IP on Wi-Fi.',
            style: TextStyle(
              color: Color(0xFF9CA7C4),
              fontSize: 13,
              height: 1.45,
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: controller,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              labelText: 'ESP32-CAM base URL',
              labelStyle: const TextStyle(color: Color(0xFF8A92B2)),
              hintText: 'http://192.168.4.1',
              hintStyle: const TextStyle(color: Color(0xFF5F6C8A)),
              filled: true,
              fillColor: const Color(0xFF0A1321),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Color(0xFF24304D)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Color(0xFF24304D)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Color(0xFF00D4FF)),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Text(
                  'Capture: ${monitor.captureUrl}',
                  style: const TextStyle(
                    color: Color(0xFF8A92B2),
                    fontSize: 12,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: onReconnect,
                icon: const Icon(Icons.wifi_tethering_rounded),
                label: const Text('Reconnect'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MonitorCameraCard extends StatelessWidget {
  const _MonitorCameraCard({required this.monitor});

  final AiMonitorService monitor;

  @override
  Widget build(BuildContext context) {
    final frameBytes = monitor.latestFrameBytes;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF101A2B),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFF24304D)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.videocam_rounded, color: Color(0xFF00D4FF), size: 20),
              SizedBox(width: 8),
              Text(
                'ESP32-CAM Feed',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: AspectRatio(
              aspectRatio: 4 / 3,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Container(color: const Color(0xFF050A12)),
                  if (frameBytes != null) Image.memory(frameBytes, fit: BoxFit.cover),
                  if (frameBytes == null)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Text(
                          monitor.statusDetail,
                          style: const TextStyle(
                            color: Color(0xFF8A92B2),
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  if (monitor.alertVisible)
                    Container(
                      color: const Color(0x99C62828),
                      alignment: Alignment.topCenter,
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        monitor.relayActive
                            ? 'WARNING: Relay active due to drowsiness'
                            : 'WARNING: Drowsiness detected, buzzer active',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MonitorStatusCard extends StatelessWidget {
  const _MonitorStatusCard({required this.monitor});

  final AiMonitorService monitor;

  @override
  Widget build(BuildContext context) {
    final Color accent = switch (monitor.status) {
      DriverMonitorStatus.alerting => const Color(0xFFFF5252),
      DriverMonitorStatus.relayActive => const Color(0xFFFF7043),
      DriverMonitorStatus.eyesClosed => const Color(0xFFFFB300),
      DriverMonitorStatus.eyesOpen => const Color(0xFF00FF88),
      DriverMonitorStatus.noFace => const Color(0xFF9AA3C0),
      DriverMonitorStatus.sourceUnavailable => const Color(0xFFFF8C42),
      DriverMonitorStatus.error => const Color(0xFFFF5252),
      _ => const Color(0xFF00D4FF),
    };

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF101A2B),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: accent.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.health_and_safety_rounded, color: accent, size: 20),
              const SizedBox(width: 8),
              Text(
                monitor.statusLabel,
                style: TextStyle(
                  color: accent,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            monitor.statusDetail,
            style: const TextStyle(
              color: Color(0xFFB6C1DA),
              fontSize: 13,
              height: 1.45,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _StatusMetric(
                  label: 'Closed timer',
                  value: '${monitor.closedDurationSeconds.toStringAsFixed(1)}s',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatusMetric(
                  label: 'Alert threshold',
                  value: '${monitor.thresholdSeconds.toStringAsFixed(1)}s',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatusMetric extends StatelessWidget {
  const _StatusMetric({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0A1321),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF7C88A8),
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _MonitorThresholdCard extends StatelessWidget {
  const _MonitorThresholdCard({required this.monitor});

  final AiMonitorService monitor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF101A2B),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFF24304D)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Alert threshold',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Trigger warning if both eyes stay below 0.3 probability for more than ${monitor.thresholdSeconds.toStringAsFixed(1)} seconds in the ESP32-CAM feed.',
            style: const TextStyle(
              color: Color(0xFF9CA7C4),
              fontSize: 13,
              height: 1.45,
            ),
          ),
          const SizedBox(height: 16),
          Slider(
            value: monitor.thresholdSeconds,
            min: 2,
            max: 10,
            divisions: 16,
            label: '${monitor.thresholdSeconds.toStringAsFixed(1)}s',
            onChanged: monitor.setThresholdSeconds,
          ),
        ],
      ),
    );
  }
}

class _AlertRouteCard extends StatelessWidget {
  const _AlertRouteCard({
    required this.isEspConnected,
    required this.relayActive,
  });

  final bool isEspConnected;
  final bool relayActive;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF101A2B),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFF24304D)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Alert routing',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            isEspConnected
                ? relayActive
                    ? 'BLE relay escalation is active on the ESP. Buzzer ran first, then relay output turned on.'
                    : 'The ESP buzzer is armed for the first 5 seconds after the threshold. If eyes stay closed, the relay output will turn on.'
                : 'ESP alert routing is offline until the BLE controller reconnects.',
            style: const TextStyle(
              color: Color(0xFF9CA7C4),
              fontSize: 13,
              height: 1.45,
            ),
          ),
        ],
      ),
    );
  }
}
