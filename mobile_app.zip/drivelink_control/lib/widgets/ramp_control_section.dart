import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/control_provider.dart';
import '../services/bluetooth_service.dart';

class RampControlSection extends StatelessWidget {
  const RampControlSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer2<ControlProvider, BluetoothService>(
      builder: (context, ctrl, ble, _) {
        final bool movementEnabled = ble.isConnected &&
            !ctrl.rampLockLoading &&
            ctrl.rampLockState != RampLockState.locked;
        final bool rampLockEnabled = ble.isConnected &&
            ctrl.activeRamp == RampDirection.none &&
            !ctrl.rampLockCooldown &&
            !ctrl.rampLockLoading;

        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A2E),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFF2A2A4A), width: 1),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.expand_circle_down_outlined,
                    color: Color(0xFF8888AA),
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'RAMP SYSTEM',
                    style: TextStyle(
                      color: Color(0xFF8888AA),
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                      letterSpacing: 2,
                    ),
                  ),
                  const Spacer(),
                  _RampStateChip(direction: ctrl.activeRamp),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Driver 2: GPIO 13 / GPIO 14   Driver 3: GPIO 15 / GPIO 16   EN: GPIO 12',
                style: TextStyle(
                  color: Color(0xFF666688),
                  fontSize: 11,
                ),
              ),
              const SizedBox(height: 16),
              _RampNotice(
                isLocked: ctrl.rampLockState == RampLockState.locked,
              ),
              const SizedBox(height: 16),
              const _SectionLabel(
                icon: Icons.swap_vert_circle_outlined,
                label: 'MOVEMENT',
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _HoldRampButton(
                      label: 'ENTER',
                      sublabel: 'Ramp In',
                      icon: Icons.login,
                      accentColor: const Color(0xFF00D4FF),
                      enabled: movementEnabled &&
                          ctrl.activeRamp != RampDirection.out_,
                      isActive: ctrl.rampInActive,
                      onHoldStart: ctrl.rampInStart,
                      onHoldEnd: ctrl.rampStop,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _HoldRampButton(
                      label: 'EXIT',
                      sublabel: 'Ramp Out',
                      icon: Icons.logout,
                      accentColor: const Color(0xFFAA88FF),
                      enabled: movementEnabled &&
                          ctrl.activeRamp != RampDirection.in_,
                      isActive: ctrl.rampOutActive,
                      onHoldStart: ctrl.rampOutStart,
                      onHoldEnd: ctrl.rampStop,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              const Divider(color: Color(0xFF2A2A4A)),
              const SizedBox(height: 18),
              Row(
                children: [
                  const _SectionLabel(
                    icon: Icons.lock_reset_rounded,
                    label: 'WHEELCHAIR LOCK',
                  ),
                  const Spacer(),
                  _RampLockStateChip(state: ctrl.rampLockState),
                ],
              ),
              const SizedBox(height: 12),
              if (ctrl.rampLockLoading)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: SizedBox(
                      width: 28,
                      height: 28,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Color(0xFF00D4FF),
                      ),
                    ),
                  ),
                )
              else
                Row(
                  children: [
                    Expanded(
                      child: _RampLockButton(
                        label: 'LOCK',
                        icon: Icons.lock_outline_rounded,
                        accentColor: const Color(0xFFFF8C42),
                        enabled: rampLockEnabled &&
                            ctrl.rampLockState != RampLockState.locked,
                        isActive: ctrl.rampLockState == RampLockState.locked,
                        onTap: ctrl.lockRamp,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _RampLockButton(
                        label: 'UNLOCK',
                        icon: Icons.lock_open_rounded,
                        accentColor: const Color(0xFF00FF88),
                        enabled: rampLockEnabled &&
                            ctrl.rampLockState != RampLockState.unlocked,
                        isActive: ctrl.rampLockState == RampLockState.unlocked,
                        onTap: ctrl.unlockRamp,
                      ),
                    ),
                  ],
                ),
              if (ctrl.rampLockCooldown && !ctrl.rampLockLoading) ...[
                const SizedBox(height: 10),
                const Center(
                  child: Text(
                    'Please wait before sending another ramp latch command...',
                    style: TextStyle(
                      color: Color(0xFF8888AA),
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel({
    required this.icon,
    required this.label,
  });

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: const Color(0xFF8888AA), size: 16),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF8888AA),
            fontWeight: FontWeight.w700,
            fontSize: 11,
            letterSpacing: 1.8,
          ),
        ),
      ],
    );
  }
}

class _RampNotice extends StatelessWidget {
  const _RampNotice({required this.isLocked});

  final bool isLocked;

  @override
  Widget build(BuildContext context) {
    final Color accent =
        isLocked ? const Color(0xFFFFAA00) : const Color(0xFF00D4FF);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: accent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: accent.withOpacity(0.24)),
      ),
      child: Row(
        children: [
          Icon(
            isLocked ? Icons.lock_rounded : Icons.touch_app,
            color: accent,
            size: 14,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              isLocked
                  ? 'Wheelchair lock is engaged. Unlock it before running the ramp motor.'
                  : 'Press and hold ENTER or EXIT to run the ramp motor. Release to stop.',
              style: TextStyle(
                color: accent,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RampStateChip extends StatelessWidget {
  const _RampStateChip({required this.direction});

  final RampDirection direction;

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (direction) {
      RampDirection.in_ => ('RAMP IN', const Color(0xFF00D4FF)),
      RampDirection.out_ => ('RAMP OUT', const Color(0xFFAA88FF)),
      RampDirection.none => ('IDLE', const Color(0xFF666688)),
    };

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class _RampLockStateChip extends StatelessWidget {
  const _RampLockStateChip({required this.state});

  final RampLockState state;

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (state) {
      RampLockState.locked => ('LOCKED', const Color(0xFFFF8C42)),
      RampLockState.unlocked => ('UNLOCKED', const Color(0xFF00FF88)),
      RampLockState.unknown => ('UNKNOWN', const Color(0xFF666688)),
    };

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class _HoldRampButton extends StatefulWidget {
  const _HoldRampButton({
    required this.label,
    required this.sublabel,
    required this.icon,
    required this.accentColor,
    required this.enabled,
    required this.isActive,
    required this.onHoldStart,
    required this.onHoldEnd,
  });

  final String label;
  final String sublabel;
  final IconData icon;
  final Color accentColor;
  final bool enabled;
  final bool isActive;
  final VoidCallback onHoldStart;
  final VoidCallback onHoldEnd;

  @override
  State<_HoldRampButton> createState() => _HoldRampButtonState();
}

class _HoldRampButtonState extends State<_HoldRampButton> {
  bool _pressing = false;

  void _startHold() {
    if (!widget.enabled || _pressing) {
      return;
    }

    setState(() => _pressing = true);
    widget.onHoldStart();
  }

  void _endHold() {
    if (!_pressing) {
      return;
    }

    setState(() => _pressing = false);
    widget.onHoldEnd();
  }

  @override
  Widget build(BuildContext context) {
    final Color color =
        widget.enabled ? widget.accentColor : const Color(0xFF333355);

    return Listener(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => _startHold(),
        onTapUp: (_) => _endHold(),
        onTapCancel: _endHold,
        child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: 110,
        decoration: BoxDecoration(
          color: widget.isActive
              ? widget.accentColor.withOpacity(0.18)
              : _pressing
                  ? widget.accentColor.withOpacity(0.12)
                  : widget.enabled
                      ? widget.accentColor.withOpacity(0.06)
                      : const Color(0xFF111128),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: widget.isActive
                ? widget.accentColor.withOpacity(0.8)
                : widget.enabled
                    ? widget.accentColor.withOpacity(0.3)
                    : const Color(0xFF333355),
            width: widget.isActive ? 2.0 : 1.5,
          ),
          boxShadow: widget.isActive
              ? [
                  BoxShadow(
                    color: widget.accentColor.withOpacity(0.3),
                    blurRadius: 20,
                    spreadRadius: 1,
                  ),
                ]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(widget.icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(
              widget.label,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w900,
                fontSize: 14,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              widget.sublabel,
              style: TextStyle(
                color: color.withOpacity(0.6),
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        ),
      ),
    );
  }
}

class _RampLockButton extends StatelessWidget {
  const _RampLockButton({
    required this.label,
    required this.icon,
    required this.accentColor,
    required this.enabled,
    required this.isActive,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color accentColor;
  final bool enabled;
  final bool isActive;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color effectiveColor =
        enabled ? accentColor : const Color(0xFF333355);
    final Color backgroundColor = isActive
        ? accentColor.withOpacity(0.15)
        : enabled
            ? accentColor.withOpacity(0.06)
            : const Color(0xFF111128);

    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 72,
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isActive
                ? accentColor.withOpacity(0.7)
                : accentColor.withOpacity(0.25),
            width: isActive ? 2 : 1,
          ),
          boxShadow: isActive
              ? [
                  BoxShadow(
                    color: accentColor.withOpacity(0.2),
                    blurRadius: 14,
                    spreadRadius: 0,
                  ),
                ]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: effectiveColor, size: 22),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: effectiveColor,
                fontWeight: FontWeight.w800,
                fontSize: 12,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
