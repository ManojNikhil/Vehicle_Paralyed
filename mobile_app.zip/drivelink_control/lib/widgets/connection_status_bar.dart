import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/bluetooth_service.dart';

class ConnectionStatusBar extends StatelessWidget {
  const ConnectionStatusBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<BluetoothService>(
      builder: (context, ble, _) {
        final (color, icon, pulse) = _stateVisuals(ble.state);

        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A2E),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.4), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.15),
                blurRadius: 12,
                spreadRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: [
              _PulsingDot(color: color, pulse: pulse),
              const SizedBox(width: 12),
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _stateLabel(ble.state),
                      style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        letterSpacing: 1.2,
                      ),
                    ),
                    Text(
                      ble.statusMessage,
                      style: const TextStyle(
                        color: Color(0xFF8888AA),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              if (ble.state == BleConnectionState.disconnected ||
                  ble.state == BleConnectionState.error)
                GestureDetector(
                  onTap: () => ble.startScanAndConnect(),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF00D4FF).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: const Color(0xFF00D4FF).withOpacity(0.3)),
                    ),
                    child: const Text(
                      'RETRY',
                      style: TextStyle(
                        color: Color(0xFF00D4FF),
                        fontWeight: FontWeight.w700,
                        fontSize: 11,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  String _stateLabel(BleConnectionState state) {
    return switch (state) {
      BleConnectionState.connected => 'CONNECTED',
      BleConnectionState.connecting => 'CONNECTING',
      BleConnectionState.scanning => 'SCANNING',
      BleConnectionState.disconnected => 'DISCONNECTED',
      BleConnectionState.error => 'ERROR',
    };
  }

  (Color, IconData, bool) _stateVisuals(BleConnectionState state) {
    return switch (state) {
      BleConnectionState.connected =>
        (const Color(0xFF00FF88), Icons.bluetooth_connected, false),
      BleConnectionState.connecting =>
        (const Color(0xFFFFAA00), Icons.bluetooth_searching, true),
      BleConnectionState.scanning =>
        (const Color(0xFF00D4FF), Icons.radar, true),
      BleConnectionState.disconnected =>
        (const Color(0xFF666688), Icons.bluetooth_disabled, false),
      BleConnectionState.error =>
        (const Color(0xFFFF4466), Icons.error_outline, false),
    };
  }
}

class _PulsingDot extends StatefulWidget {
  final Color color;
  final bool pulse;

  const _PulsingDot({required this.color, required this.pulse});

  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.3, end: 1.0).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.pulse) {
      return Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(
          color: widget.color,
          shape: BoxShape.circle,
        ),
      );
    }
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Opacity(
        opacity: _anim.value,
        child: Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: widget.color,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6),
            ],
          ),
        ),
      ),
    );
  }
}
