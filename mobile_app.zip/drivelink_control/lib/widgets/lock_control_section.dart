import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/control_provider.dart' as control_provider_alias;
import '../providers/control_provider.dart' show ControlProvider;
import '../services/bluetooth_service.dart';

class LockControlSection extends StatelessWidget {
  const LockControlSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer2<ControlProvider, BluetoothService>(
      builder: (context, ctrl, ble, _) {
        final bool enabled = !ctrl.lockCooldown && !ctrl.lockLoading;

        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A2E),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFF2A2A4A), width: 1),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.lock_outline,
                    color: Color(0xFF8888AA),
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'DOOR LOCK',
                    style: TextStyle(
                      color: Color(0xFF8888AA),
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                      letterSpacing: 2,
                    ),
                  ),
                  const Spacer(),
                  _LockStateChip(state: ctrl.lockState),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Single-board ESP32-S3 profile: no separate door lock output is used.',
                style: TextStyle(
                  color: Color(0xFF666688),
                  fontSize: 11,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                ble.isConnected
                    ? 'Door lock buttons are visible for reference only.'
                    : 'Door lock buttons stay visible even without ESP control.',
                style: const TextStyle(
                  color: Color(0xFF666688),
                  fontSize: 11,
                ),
              ),
              const SizedBox(height: 20),
              if (ctrl.lockLoading)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: SizedBox(
                      width: 28,
                      height: 28,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Color(0xFF00D4FF),
                      ),
                    ),
                  ),
                )
              else
                Row(
                  children: [
                    Expanded(
                      child: _LockButton(
                        label: 'LOCK',
                        icon: Icons.lock,
                        accentColor: const Color(0xFFFF4466),
                        enabled: enabled &&
                            ctrl.lockState !=
                                control_provider_alias.LockState.locked,
                        onTap: ctrl.lock,
                        isActive: ctrl.lockState ==
                            control_provider_alias.LockState.locked,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _LockButton(
                        label: 'UNLOCK',
                        icon: Icons.lock_open,
                        accentColor: const Color(0xFF00FF88),
                        enabled: enabled &&
                            ctrl.lockState !=
                                control_provider_alias.LockState.unlocked,
                        onTap: ctrl.unlock,
                        isActive: ctrl.lockState ==
                            control_provider_alias.LockState.unlocked,
                      ),
                    ),
                  ],
                ),
              if (ctrl.lockCooldown && !ctrl.lockLoading) ...[
                const SizedBox(height: 10),
                const Center(
                  child: Text(
                    'Please wait...',
                    style: TextStyle(
                      color: Color(0xFF8888AA),
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}

class _LockStateChip extends StatelessWidget {
  const _LockStateChip({required this.state});

  final control_provider_alias.LockState state;

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (state) {
      control_provider_alias.LockState.locked => (
          'LOCKED',
          const Color(0xFFFF4466),
        ),
      control_provider_alias.LockState.unlocked => (
          'UNLOCKED',
          const Color(0xFF00FF88),
        ),
      control_provider_alias.LockState.unknown => (
          'UNKNOWN',
          const Color(0xFF666688),
        ),
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.5,
        ),
      ),
    );
  }
}

class _LockButton extends StatelessWidget {
  const _LockButton({
    required this.label,
    required this.icon,
    required this.accentColor,
    required this.enabled,
    required this.isActive,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color accentColor;
  final bool enabled;
  final bool isActive;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color effectiveColor =
        enabled ? accentColor : const Color(0xFF333355);
    final Color backgroundColor = isActive
        ? accentColor.withOpacity(0.15)
        : enabled
            ? accentColor.withOpacity(0.06)
            : const Color(0xFF111128);

    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 72,
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isActive
                ? accentColor.withOpacity(0.7)
                : accentColor.withOpacity(0.25),
            width: isActive ? 2 : 1,
          ),
          boxShadow: isActive
              ? [
                  BoxShadow(
                    color: accentColor.withOpacity(0.2),
                    blurRadius: 14,
                    spreadRadius: 0,
                  ),
                ]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: effectiveColor, size: 22),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: effectiveColor,
                fontWeight: FontWeight.w800,
                fontSize: 12,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
