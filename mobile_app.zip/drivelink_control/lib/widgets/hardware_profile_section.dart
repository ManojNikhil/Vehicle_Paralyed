import 'package:flutter/material.dart';

class HardwareProfileSection extends StatelessWidget {
  const HardwareProfileSection({super.key});

  static const List<_PinAssignment> _pins = [
    _PinAssignment('Camera Feed', 'GPIO 4-18', 'Reserved by ESP32-S3 camera'),
    _PinAssignment('Buzzer', 'GPIO 2', 'First 5 seconds of alert'),
    _PinAssignment('Relay', 'GPIO 45', 'Turns on if eyes remain closed'),
    _PinAssignment('Ramp RPWM', 'GPIO 39', 'Ramp move forward'),
    _PinAssignment('Ramp LPWM', 'GPIO 40', 'Ramp move reverse'),
    _PinAssignment('Drivers ENABLE', 'GPIO 47', 'Shared motor enable'),
    _PinAssignment('Wheelchair RPWM', 'GPIO 48', 'Wheelchair lock forward'),
    _PinAssignment('Wheelchair LPWM', 'GPIO 1', 'Wheelchair lock reverse'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF2A2A4A), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.memory_rounded,
                color: Color(0xFF8888AA),
                size: 18,
              ),
              SizedBox(width: 8),
              Text(
                'ESP32 PIN PROFILE',
                style: TextStyle(
                  color: Color(0xFF8888AA),
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Text(
            'This single-board ESP32-S3 profile uses the built-in camera for Driver Monitor and uses only the free GPIOs for ramp, wheelchair lock, buzzer, and relay.',
            style: TextStyle(
              color: Color(0xFF8888AA),
              fontSize: 12,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: _pins
                .map(
                  (pin) => _PinChip(
                    label: pin.label,
                    pin: pin.pin,
                    note: pin.note,
                  ),
                )
                .toList(),
          ),
        ],
      ),
    );
  }
}

class _PinChip extends StatelessWidget {
  const _PinChip({
    required this.label,
    required this.pin,
    required this.note,
  });

  final String label;
  final String pin;
  final String note;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 150,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF111128),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF2F335C)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            pin,
            style: const TextStyle(
              color: Color(0xFF00D4FF),
              fontSize: 12,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            note,
            style: const TextStyle(
              color: Color(0xFF7A7FA8),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

class _PinAssignment {
  const _PinAssignment(this.label, this.pin, this.note);

  final String label;
  final String pin;
  final String note;
}
