import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'providers/control_provider.dart';
import 'screens/home_screen.dart';
import 'services/ai_monitor_service.dart';
import 'services/bluetooth_service.dart';
import 'services/permission_helper.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const AutoNexusXApp());
}

class AutoNexusXApp extends StatelessWidget {
  const AutoNexusXApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => BluetoothService()),
        ChangeNotifierProxyProvider<BluetoothService, ControlProvider>(
          create: (context) =>
              ControlProvider(context.read<BluetoothService>()),
          update: (_, ble, previous) => previous ?? ControlProvider(ble),
        ),
        ChangeNotifierProxyProvider<BluetoothService, AiMonitorService>(
          create: (context) =>
              AiMonitorService(context.read<BluetoothService>()),
          update: (_, ble, previous) {
            final service = previous ?? AiMonitorService(ble);
            service.updateBluetoothService(ble);
            return service;
          },
        ),
      ],
      child: MaterialApp(
        title: 'AutoNexus-X',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF00D4FF),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFF0D0D1F),
        ),
        home: const _PermissionGate(),
      ),
    );
  }
}

class _PermissionGate extends StatefulWidget {
  const _PermissionGate();

  @override
  State<_PermissionGate> createState() => _PermissionGateState();
}

class _PermissionGateState extends State<_PermissionGate> {
  bool _checking = true;
  bool _granted = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final ok = await PermissionHelper.requestBlePermissions(context);
    if (!mounted) {
      return;
    }

    setState(() {
      _checking = false;
      _granted = ok;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_checking) {
      return const Scaffold(
        backgroundColor: Color(0xFF0D0D1F),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: Color(0xFF00D4FF)),
              SizedBox(height: 20),
              Text(
                'Requesting permissions...',
                style: TextStyle(color: Color(0xFF8888AA), fontSize: 14),
              ),
            ],
          ),
        ),
      );
    }

    if (!_granted) {
      return Scaffold(
        backgroundColor: const Color(0xFF0D0D1F),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.bluetooth_disabled,
                  color: Color(0xFFFF4466),
                  size: 56,
                ),
                const SizedBox(height: 20),
                const Text(
                  'Bluetooth Permission Denied',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),
                const Text(
                  'AutoNexus-X needs Bluetooth access to connect to your ESP32 controller. Please grant permissions in Settings.',
                  style: TextStyle(color: Color(0xFF8888AA), fontSize: 14),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 28),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00D4FF),
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 28,
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  icon: const Icon(Icons.refresh),
                  label: const Text(
                    'Retry',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  onPressed: _check,
                ),
              ],
            ),
          ),
        ),
      );
    }

    return const HomeScreen();
  }
}
