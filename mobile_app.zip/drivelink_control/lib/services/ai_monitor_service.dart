import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:vibration/vibration.dart';

import 'bluetooth_service.dart';

enum DriverMonitorStatus {
  idle,
  preparing,
  ready,
  noFace,
  eyesOpen,
  eyesClosed,
  alerting,
  relayActive,
  sourceUnavailable,
  error,
}

class AiMonitorService extends ChangeNotifier {
  AiMonitorService(this._bluetoothService) {
    _faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        enableClassification: true,
        enableContours: false,
        enableLandmarks: false,
        performanceMode: FaceDetectorMode.accurate,
      ),
    );
    _audioPlayer = AudioPlayer();
  }

  static const double closedEyeThreshold = 0.3;
  static const Duration blinkIgnoreDuration = Duration(milliseconds: 450);
  static const Duration capturePollInterval = Duration(milliseconds: 650);
  static const Duration requestTimeout = Duration(seconds: 4);
  static const Duration relayEscalationDelay = Duration(seconds: 5);
  static const String _defaultEspCamBaseUrl = 'http://192.168.4.1';

  BluetoothService _bluetoothService;
  late final FaceDetector _faceDetector;
  late final AudioPlayer _audioPlayer;

  DriverMonitorStatus _status = DriverMonitorStatus.idle;
  String _statusDetail = 'Open Driver Monitor to start.';
  double _thresholdSeconds = 5;
  double _closedDurationSeconds = 0;
  bool _alertVisible = false;
  bool _relayActive = false;
  bool _isMonitoring = false;
  bool _isInitialized = false;
  bool _isProcessingFrame = false;
  String _espCamBaseUrl = _defaultEspCamBaseUrl;
  String? _lastError;
  Uint8List? _latestFrameBytes;
  Timer? _captureTimer;
  DateTime? _closedEyesCandidateAt;
  DateTime? _closedEyesStartedAt;
  DateTime? _alertStartedAt;

  DriverMonitorStatus get status => _status;
  String get statusDetail => _statusDetail;
  double get thresholdSeconds => _thresholdSeconds;
  double get closedDurationSeconds => _closedDurationSeconds;
  bool get alertVisible => _alertVisible;
  bool get relayActive => _relayActive;
  bool get isMonitoring => _isMonitoring;
  bool get isInitialized => _isInitialized;
  String get espCamBaseUrl => _espCamBaseUrl;
  String get captureUrl => '${_normalizedBaseUrl()}/capture';
  String get streamUrl => '${_normalizedBaseUrl()}:81/stream';
  String? get lastError => _lastError;
  Uint8List? get latestFrameBytes => _latestFrameBytes;

  String get statusLabel {
    return switch (_status) {
      DriverMonitorStatus.idle => 'Idle',
      DriverMonitorStatus.preparing => 'Preparing',
      DriverMonitorStatus.ready => 'Ready',
      DriverMonitorStatus.noFace => 'No Face',
      DriverMonitorStatus.eyesOpen => 'Eyes Open',
      DriverMonitorStatus.eyesClosed => 'Eyes Closed',
      DriverMonitorStatus.alerting => 'Buzzer Active',
      DriverMonitorStatus.relayActive => 'Relay Active',
      DriverMonitorStatus.sourceUnavailable => 'Feed Offline',
      DriverMonitorStatus.error => 'Error',
    };
  }

  void updateBluetoothService(BluetoothService bluetoothService) {
    _bluetoothService = bluetoothService;
  }

  void updateEspCamBaseUrl(String value) {
    _espCamBaseUrl = value.trim().isEmpty ? _defaultEspCamBaseUrl : value.trim();
    notifyListeners();
  }

  void setThresholdSeconds(double value) {
    _thresholdSeconds = value.clamp(2, 10);
    notifyListeners();
  }

  Future<void> initializeMonitoring() async {
    if (_isMonitoring) {
      return;
    }

    _setStatus(
      DriverMonitorStatus.preparing,
      'Connecting to ESP32-CAM feed and starting eye tracking...',
    );

    _isMonitoring = true;
    _isInitialized = true;
    _captureTimer?.cancel();
    _captureTimer = Timer.periodic(capturePollInterval, (_) {
      unawaited(_processEspCamFrame());
    });
    await _processEspCamFrame();
  }

  Future<void> stopMonitoring() async {
    _captureTimer?.cancel();
    _captureTimer = null;
    _closedEyesCandidateAt = null;
    _closedEyesStartedAt = null;
    _alertStartedAt = null;
    _closedDurationSeconds = 0;
    _latestFrameBytes = null;
    _isMonitoring = false;
    _isInitialized = false;
    _isProcessingFrame = false;
    await _clearAlertState();
    _setStatus(DriverMonitorStatus.idle, 'Driver Monitor stopped.');
  }

  Future<void> _processEspCamFrame() async {
    if (!_isMonitoring || _isProcessingFrame) {
      return;
    }

    _isProcessingFrame = true;
    final now = DateTime.now();

    try {
      final response = await http
          .get(Uri.parse(captureUrl))
          .timeout(requestTimeout);

      if (response.statusCode != 200 || response.bodyBytes.isEmpty) {
        throw HttpException('ESP32-CAM capture failed with ${response.statusCode}');
      }

      _latestFrameBytes = response.bodyBytes;
      final imagePath = await _writeFrameToTempFile(response.bodyBytes);
      final inputImage = InputImage.fromFilePath(imagePath);
      final faces = await _faceDetector.processImage(inputImage);
      _handleFaceResults(faces, now);
    } catch (error) {
      _lastError = error.toString();
      _resetClosedEyeState();
      await _clearAlertState();
      _setStatus(
        DriverMonitorStatus.sourceUnavailable,
        'Unable to reach ESP32-CAM at ${_normalizedBaseUrl()}. Check Wi-Fi and camera power.',
      );
    } finally {
      _isProcessingFrame = false;
    }
  }

  Future<String> _writeFrameToTempFile(Uint8List bytes) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/esp32cam_frame.jpg');
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  Future<void> _handleFaceResults(List<Face> faces, DateTime now) async {
    if (faces.isEmpty) {
      _resetClosedEyeState();
      await _clearAlertState();
      _setStatus(
        DriverMonitorStatus.noFace,
        'No face detected in the ESP32-CAM feed.',
      );
      return;
    }

    final face = faces.first;
    final leftEye = face.leftEyeOpenProbability;
    final rightEye = face.rightEyeOpenProbability;

    if (leftEye == null || rightEye == null) {
      _resetClosedEyeState();
      await _clearAlertState();
      _setStatus(
        DriverMonitorStatus.eyesOpen,
        'Face found, but eye confidence is low. Hold the face steady in front of the ESP32-CAM.',
      );
      return;
    }

    final bothEyesClosed =
        leftEye < closedEyeThreshold && rightEye < closedEyeThreshold;

    if (!bothEyesClosed) {
      _resetClosedEyeState();
      await _clearAlertState();
      _setStatus(
        DriverMonitorStatus.eyesOpen,
        'Eyes open and feed tracking is healthy.',
      );
      return;
    }

    _closedEyesCandidateAt ??= now;
    final candidateDuration = now.difference(_closedEyesCandidateAt!);
    if (candidateDuration < blinkIgnoreDuration) {
      _closedDurationSeconds = 0;
      _setStatus(
        DriverMonitorStatus.eyesOpen,
        'Blink detected. Waiting before starting the closure timer...',
      );
      return;
    }

    _closedEyesStartedAt ??= _closedEyesCandidateAt!;
    _closedDurationSeconds =
        now.difference(_closedEyesStartedAt!).inMilliseconds / 1000;

    if (_closedDurationSeconds >= _thresholdSeconds) {
      await _triggerAlert(now);
      return;
    }

    _setStatus(
      DriverMonitorStatus.eyesClosed,
      'Eyes closed for ${_closedDurationSeconds.toStringAsFixed(1)}s.',
    );
  }

  Future<void> _triggerAlert(DateTime now) async {
    if (!_alertVisible) {
      _alertVisible = true;
      _relayActive = false;
      _alertStartedAt = now;

      try {
        await _audioPlayer.stop();
        await _audioPlayer.setReleaseMode(ReleaseMode.loop);
        await _audioPlayer.play(AssetSource('audio/alert.wav'), volume: 1.0);
      } catch (_) {}

      try {
        final hasVibrator = await Vibration.hasVibrator();
        if (hasVibrator) {
          await Vibration.vibrate(pattern: [0, 250, 120, 350, 120, 450]);
        }
      } catch (_) {}

      if (_bluetoothService.isConnected) {
        unawaited(_bluetoothService.sendCommand('ALERT_SLEEP_START'));
      }
    }

    final alertAge = _alertStartedAt == null
        ? Duration.zero
        : now.difference(_alertStartedAt!);

    if (!_relayActive && alertAge >= relayEscalationDelay) {
      _relayActive = true;
      if (_bluetoothService.isConnected) {
        unawaited(_bluetoothService.sendCommand('ALERT_RELAY_ON'));
      }
      _setStatus(
        DriverMonitorStatus.relayActive,
        'Eyes still closed. Relay output is now active.',
      );
      return;
    }

    _setStatus(
      DriverMonitorStatus.alerting,
      _relayActive
          ? 'Relay active while eyes remain closed.'
          : 'Buzzer active for the first 5 seconds of the alert.',
    );
  }

  Future<void> _clearAlertState() async {
    final hadAlert = _alertVisible || _relayActive;
    _alertVisible = false;
    _relayActive = false;
    _alertStartedAt = null;

    try {
      await _audioPlayer.stop();
    } catch (_) {}

    if (hadAlert && _bluetoothService.isConnected) {
      unawaited(_bluetoothService.sendCommand('ALERT_CLEAR'));
    }
  }

  void _resetClosedEyeState() {
    _closedEyesCandidateAt = null;
    _closedEyesStartedAt = null;
    _closedDurationSeconds = 0;
  }

  String _normalizedBaseUrl() {
    final raw = _espCamBaseUrl.trim();
    if (raw.isEmpty) {
      return _defaultEspCamBaseUrl;
    }
    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      return raw;
    }
    return 'http://$raw';
  }

  void _setStatus(DriverMonitorStatus status, String detail) {
    _status = status;
    _statusDetail = detail;
    notifyListeners();
  }

  @override
  void dispose() {
    _captureTimer?.cancel();
    unawaited(_faceDetector.close());
    _audioPlayer.dispose();
    super.dispose();
  }
}
