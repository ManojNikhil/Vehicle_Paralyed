import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart' as blue;

enum BleConnectionState {
  disconnected,
  scanning,
  connecting,
  connected,
  error,
}

class BluetoothService extends ChangeNotifier {
  static const List<String> _targetDeviceNames = <String>[
    'ESP32_DRIVE',
    'ESP32',
    'AutoNexus-X',
    'AutoNexus_X',
  ];
  static const String _serviceUuid = '6e400001-b5a3-f393-e0a9-e50e24dcca9e';
  static const String _notifyCharUuid = '6e400002-b5a3-f393-e0a9-e50e24dcca9e';
  static const String _writeCharUuid = '6e400003-b5a3-f393-e0a9-e50e24dcca9e';

  BleConnectionState _state = BleConnectionState.disconnected;
  blue.BluetoothDevice? _device;
  blue.BluetoothCharacteristic? _txCharacteristic;
  String _statusMessage = 'Not connected';
  bool _isReconnecting = false;

  StreamSubscription<List<blue.ScanResult>>? _scanSubscription;
  StreamSubscription<blue.BluetoothConnectionState>? _connectionSubscription;
  Timer? _reconnectTimer;
  Timer? _scanTimeoutTimer;

  BleConnectionState get state => _state;
  bool get isConnected => _state == BleConnectionState.connected;
  String get statusMessage => _statusMessage;

  void _setState(BleConnectionState newState, String message) {
    _state = newState;
    _statusMessage = message;
    notifyListeners();
  }

  Future<void> startScanAndConnect() async {
    if (_state == BleConnectionState.scanning ||
        _state == BleConnectionState.connecting ||
        _state == BleConnectionState.connected) {
      return;
    }

    await _cleanup();
    _setState(
      BleConnectionState.scanning,
      'Scanning for compatible ESP32 boards...',
    );

    try {
      if (await blue.FlutterBluePlus.adapterState.first !=
          blue.BluetoothAdapterState.on) {
        _setState(
            BleConnectionState.error, 'Bluetooth is off. Please enable it.');
        return;
      }

      _scanTimeoutTimer = Timer(const Duration(seconds: 15), () {
        if (_state == BleConnectionState.scanning) {
          blue.FlutterBluePlus.stopScan();
          _setState(
            BleConnectionState.disconnected,
            'Device not found. Tap to retry.',
          );
        }
      });

      await blue.FlutterBluePlus.startScan(
          timeout: const Duration(seconds: 15));

      _scanSubscription =
          blue.FlutterBluePlus.scanResults.listen((results) async {
        for (final result in results) {
          if (_isTargetDevice(result)) {
            await blue.FlutterBluePlus.stopScan();
            await _scanSubscription?.cancel();
            _scanTimeoutTimer?.cancel();
            await _connectToDevice(result.device);
            return;
          }
        }
      });
    } catch (error) {
      _setState(BleConnectionState.error, 'Scan error: ${error.toString()}');
    }
  }

  Future<void> _connectToDevice(blue.BluetoothDevice device) async {
    final name = device.platformName.trim().isEmpty
        ? 'ESP32 board'
        : device.platformName.trim();
    _setState(BleConnectionState.connecting, 'Connecting to $name...');
    _device = device;

    try {
      await device.connect(
        timeout: const Duration(seconds: 15),
        autoConnect: false,
      );

      _connectionSubscription = device.connectionState.listen((state) {
        if (state == blue.BluetoothConnectionState.disconnected) {
          _handleDisconnect();
        }
      });

      await _discoverServices(device);
    } catch (error) {
      _setState(
        BleConnectionState.error,
        'Connection failed: ${error.toString()}',
      );
      _scheduleReconnect();
    }
  }

  Future<void> _discoverServices(blue.BluetoothDevice device) async {
    try {
      final services = await device.discoverServices();

      for (final service in services) {
        if (service.uuid.str128.toLowerCase() != _serviceUuid) {
          continue;
        }

        for (final characteristic in service.characteristics) {
          final uuid = characteristic.uuid.str128.toLowerCase();
          if (uuid == _writeCharUuid && characteristic.properties.write) {
            _txCharacteristic = characteristic;
          } else if (uuid == _writeCharUuid &&
              characteristic.properties.writeWithoutResponse) {
            _txCharacteristic ??= characteristic;
          }

          if (uuid == _notifyCharUuid && characteristic.properties.notify) {
            await characteristic.setNotifyValue(true);
          }
        }
      }

      if (_txCharacteristic == null) {
        outer:
        for (final service in services) {
          for (final characteristic in service.characteristics) {
            if (characteristic.properties.write ||
                characteristic.properties.writeWithoutResponse) {
              _txCharacteristic = characteristic;
              break outer;
            }
          }
        }
      }

      if (_txCharacteristic == null) {
        _setState(
          BleConnectionState.error,
          'No writable BLE characteristic found on the ESP32.',
        );
        await device.disconnect();
        return;
      }

      final name = device.platformName.trim().isEmpty
          ? 'ESP32 board'
          : device.platformName.trim();
      _isReconnecting = false;
      _setState(BleConnectionState.connected, 'Connected to $name');
    } catch (error) {
      _setState(BleConnectionState.error, 'Service discovery failed.');
      await device.disconnect();
      _scheduleReconnect();
    }
  }

  Future<bool> sendCommand(String command) async {
    if (!isConnected || _txCharacteristic == null) {
      return false;
    }

    try {
      final bytes = utf8.encode('$command\n');
      if (_txCharacteristic!.properties.write) {
        await _txCharacteristic!.write(bytes, withoutResponse: false);
      } else {
        await _txCharacteristic!.write(bytes, withoutResponse: true);
      }
      debugPrint('BLE TX: $command');
      return true;
    } catch (error) {
      debugPrint('BLE send error: $error');
      _handleDisconnect();
      return false;
    }
  }

  bool _isTargetDevice(blue.ScanResult result) {
    final deviceName = result.device.platformName.trim();
    final advertisedName = result.advertisementData.advName.trim();
    final matchesName = _targetDeviceNames.any(
      (target) => target == deviceName || target == advertisedName,
    );
    final matchesService = result.advertisementData.serviceUuids.any(
      (uuid) => uuid.str128.toLowerCase() == _serviceUuid,
    );
    return matchesName || matchesService;
  }

  void _handleDisconnect() {
    if (_state == BleConnectionState.disconnected ||
        _state == BleConnectionState.scanning) {
      return;
    }

    _txCharacteristic = null;
    _setState(
      BleConnectionState.disconnected,
      'Disconnected. Reconnecting...',
    );
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    if (_isReconnecting) {
      return;
    }

    _isReconnecting = true;
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 3), () {
      if (_state != BleConnectionState.connected) {
        startScanAndConnect();
      }
    });
  }

  Future<void> disconnect() async {
    _reconnectTimer?.cancel();
    _isReconnecting = false;
    await _cleanup();
    _setState(BleConnectionState.disconnected, 'Disconnected');
  }

  Future<void> _cleanup() async {
    await _scanSubscription?.cancel();
    await _connectionSubscription?.cancel();
    _scanTimeoutTimer?.cancel();
    _scanSubscription = null;
    _connectionSubscription = null;
    _txCharacteristic = null;

    try {
      await blue.FlutterBluePlus.stopScan();
    } catch (_) {}

    try {
      await _device?.disconnect();
    } catch (_) {}

    _device = null;
  }

  @override
  void dispose() {
    unawaited(_cleanup());
    _reconnectTimer?.cancel();
    super.dispose();
  }
}
