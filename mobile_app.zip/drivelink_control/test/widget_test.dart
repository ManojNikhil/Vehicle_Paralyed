import 'package:flutter_test/flutter_test.dart';

import 'package:drivelink_control/providers/control_provider.dart';
import 'package:drivelink_control/services/bluetooth_service.dart';

class _FakeBluetoothService extends BluetoothService {
  _FakeBluetoothService({this.connected = true});

  final List<String> sentCommands = <String>[];
  bool connected;

  @override
  bool get isConnected => connected;

  @override
  Future<bool> sendCommand(String command) async {
    sentCommands.add(command);
    return true;
  }
}

void main() {
  test('control provider starts disconnected-safe', () {
    final provider = ControlProvider(_FakeBluetoothService(connected: false));

    expect(provider.lockState, LockState.unknown);
    expect(provider.activeRamp, RampDirection.none);
    expect(provider.rampLockState, RampLockState.unknown);
  });

  test('ramp latch commands update state and send BLE payloads', () async {
    final fakeBle = _FakeBluetoothService();
    final provider = ControlProvider(fakeBle);

    await provider.lockRamp();
    await Future<void>.delayed(const Duration(seconds: 3));
    await provider.unlockRamp();

    expect(fakeBle.sentCommands, <String>['RAMP_LOCK', 'RAMP_UNLOCK']);
    expect(provider.rampLockState, RampLockState.unlocked);
  });

  test('locked ramp latch blocks movement commands', () async {
    final fakeBle = _FakeBluetoothService();
    final provider = ControlProvider(fakeBle);

    await provider.lockRamp();
    await provider.rampInStart();

    expect(fakeBle.sentCommands, <String>['RAMP_LOCK']);
    expect(provider.activeRamp, RampDirection.none);
  });
}
